﻿namespace BashSoft
{
    public static class Launcher
    {
        static void Main()
        {
            // IOManager.TraverseDirectory(@"D:\github\BashSoft-FirstWeek");

            //  StudentRepository.InitializeData();
            //  StudentRepository.GetAllStudentsFromCourse("Unity");

            //  StudentRepository.InitializeData();
            // StudentRepository.GetStudentScoresFromCourse("Unity", "Ivan");

            //   Tester.CompareContent(@"D:\github\BashSoft-FirstWeek\BashSoft-FirstWeek\03. CSharp-Advanced-Files-And-Directories-Lab\test1.txt", @"D:\github\BashSoft-FirstWeek\BashSoft-FirstWeek\03. CSharp-Advanced-Files-And-Directories-Lab\test2.txt");

            //Tester.CompareContent(@"D:\github\BashSoft-FirstWeek\BashSoft-FirstWeek\03. CSharp-Advanced-Files-And-Directories-Lab\test2.txt", @"D:\github\BashSoft-FirstWeek\BashSoft-FirstWeek\03. CSharp-Advanced-Files-And-Directories-Lab\test3.txt");

            //  IOManager.CreateDirectoryInCurrentFolder("pesho");

           // IOManager.TraverseDirectory(0);

          //  IOManager.ChangeCurrentDirectoryAbsolute(@"C:\Windows");
            //IOManager.TraverseDirectory(20);

            InputReader.StartReadingCommands();
        }
    }
}
